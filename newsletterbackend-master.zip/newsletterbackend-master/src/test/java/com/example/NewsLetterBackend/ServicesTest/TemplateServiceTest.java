package com.example.NewsLetterBackend.ServicesTest;

import com.example.NewsLetterBackend.Entities.MeetingTemplate;
import com.example.NewsLetterBackend.Entities.Template;
import com.example.NewsLetterBackend.Entities.User;
import com.example.NewsLetterBackend.Repositories.TemplateRepository;
import com.example.NewsLetterBackend.Repositories.UserRepository;
import com.example.NewsLetterBackend.Requests.AddTemplateRequest;
import com.example.NewsLetterBackend.Services.TemplateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;
import java.text.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

@SpringBootTest
public class TemplateServiceTest {
    private TemplateService templateService;
    @Mock TemplateRepository templateRepository;
    @Mock UserRepository userRepository;
    private final static Logger LOGGER =
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    @BeforeEach
    public void setup(){
        MockitoAnnotations.initMocks(this);
        templateService = new TemplateService(templateRepository, userRepository);
    }
    @Test
    void saveTemplateTest() throws ParseException {
        User user1 = new User("kunal1","123", "kunal singh", "i am developer", new ArrayList<>());
        String dnow = "2021-08-01";
        Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dnow);
        Template template = new MeetingTemplate("meeting", "kunal1","kunal",date1,"hashedin","new hashers","building new project");
        AddTemplateRequest addTemplateRequest = new AddTemplateRequest("meeting","kunal1",null,null,null,null,"kunal",date1,"hashedin","new hashers","building new project",null,null,null,null,null);
        Mockito.when(templateRepository.save(Mockito.any())).thenReturn(template);
        Template response = templateService.saveTemplate(addTemplateRequest,"kunal1");
        assertThat(response.getTemplateId(), equalTo(template.getTemplateId()));
    }

    @Test
    void getAllTemplate() throws ParseException {
        User user1 = new User("kunal1","123", "kunal singh", "i am developer", new ArrayList<>());
        String dnow = "2021-08-01";
        Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dnow);
        Template template1 = new MeetingTemplate("meeting", "kunal1","kunal",date1,"hashedin","new hashers","building new project");
        Template template2 = new MeetingTemplate("meeting", "kunal1","kunal",date1,"hashedin","new hashers","building new project");

        List<Template> temp = new ArrayList<>();
        temp.add(template1);
        temp.add(template2);

        Mockito.when(templateRepository.findAll()).thenReturn(temp);
        List<Template> response = templateService.getAllTemplate();
        assertThat(response.size(), equalTo(temp.size()));
    }

    @Test
    void getTemplateByIdTest() throws ParseException {
        User user1 = new User("kunal1","123", "kunal singh", "i am developer", new ArrayList<>());
        String dnow = "2021-08-01";
        Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dnow);
        Template template1 = new MeetingTemplate("meeting", "kunal1","kunal",date1,"hashedin","new hashers","building new project");
        Long id = 101L;
        Mockito.when(templateRepository.findById(Mockito.any())).thenReturn(Optional.of(template1));
        Optional<Template> response = templateService.getTemplateById(id);
        assertThat(response.get().getTemplateId(), equalTo(template1.getTemplateId()));
    }
    @Test
    void getTemplateByIdTest2() throws ParseException {
        User user1 = new User("kunal1","123", "kunal singh", "i am developer", new ArrayList<>());
        String dnow = "2021-08-01";
        Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dnow);
        Template template1 = new MeetingTemplate("meeting", "kunal1","kunal",date1,"hashedin","new hashers","building new project");
        Long id = 1011L;
        Mockito.when(templateRepository.findById(Mockito.any())).thenReturn(Optional.of(template1));
        Optional<Template> response = templateService.getTemplateById(id);
        assertNotEquals(id, response.get().getTemplateId());
    }
    @Test
    void deleteTemplateByIdTest() throws ParseException{
        User user1 = new User("kunal1","123", "kunal singh", "i am developer", new ArrayList<>());
        String dnow = "2021-08-01";
        Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dnow);
        Template template1 = new MeetingTemplate("meeting", "kunal1","kunal",date1,"hashedin","new hashers","building new project");
        Long id = 101L;
        Mockito.when(templateRepository.findById(Mockito.any())).thenReturn(Optional.of(template1));
        try{
            String response = templateService.deleteTemplateById(id, "kunal1");
            assertEquals(response, "Template deleted successfully");
        }
        catch (NullPointerException e){
            assertThat(e.getMessage(), equalTo("Template not found with given id"));
        }
    }
    @Test
    void deleteTemplateByIdTest2() throws ParseException{
        User user1 = new User("kunal1","123", "kunal singh", "i am developer", new ArrayList<>());
        String dnow = "2021-08-01";
        Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dnow);
        Template template1 = new MeetingTemplate("meeting", "kunal1","kunal",date1,"hashedin","new hashers","building new project");
        Long id = 1011L;
        Mockito.when(templateRepository.findById(Mockito.any())).thenReturn(Optional.of(template1));
        try{
            String response = templateService.deleteTemplateById(id,"kunal1");
            // LOGGER.log(Level.INFO, response);
            assertEquals(response, "Template deleted successfully");
        }
        catch (NoSuchElementException e){
            // LOGGER.log(Level.INFO, e.getMessage());
            assertThat(e.getMessage(), equalTo("Template not found with given id"));
        }
    }
}
