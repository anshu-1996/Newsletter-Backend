package com.example.NewsLetterBackend.Services;

import com.example.NewsLetterBackend.Entities.Template;
import com.example.NewsLetterBackend.Entities.User;
import com.example.NewsLetterBackend.Repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private UserRepository userRepository;
    @Autowired
    public UserService(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }
    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    public User getUserByUsername(String username) {
        return userRepository.findByusername(username);
    }
//
//    public void deleteUser(int id) {
//        userRepository.deleteById(id);
//    }

    public User updateUser(User user, String username) {
        //for(int i = 0; i < userRepository.count(); i++) {
        try {
            User updateUser = userRepository.findByusername(username);
            updateUser.setFullName(user.getFullName());
            updateUser.setPassword(user.getPassword());
            updateUser.setPhone(user.getPhone());
            return userRepository.save(updateUser);
        } catch (Exception e) {
            return null;
        }


    }

    public List<Template> getDocumentsByUsername(String username) {
        User user = userRepository.findByusername(username);
        if(user == null){
            return null;
        }
        return user.getDocuments();
    }
}
