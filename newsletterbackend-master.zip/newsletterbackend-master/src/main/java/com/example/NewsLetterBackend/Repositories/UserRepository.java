package com.example.NewsLetterBackend.Repositories;

import com.example.NewsLetterBackend.Entities.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends MongoRepository<User, Integer> {
    public User findByusername(String username);

//    org.springframework.security.core.userdetails.User findByUserName(String username);
}
