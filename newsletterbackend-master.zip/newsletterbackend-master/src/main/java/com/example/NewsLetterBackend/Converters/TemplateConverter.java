package com.example.NewsLetterBackend.Converters;

import com.example.NewsLetterBackend.Entities.*;
import com.example.NewsLetterBackend.Requests.AddTemplateRequest;

public class TemplateConverter {

    public static Template toEntity(AddTemplateRequest template){
        String type = template.getTemplateType();
        switch(type){
            case "fun": {
                Template request = new FunTemplate(
                        template.getTemplateType(),
                        template.getCreatedBy(),
                        template.getEventName(),
                        template.getEventDescription(),
                        template.getVenue(),
                        template.getEventOn()
                );
                return request;
            }
            case "meeting":{
                Template request = new MeetingTemplate(
                        template.getTemplateType(),
                        template.getCreatedBy(),
                        template.getMeetingHeldBy(),
                        template.getMeetingHeldOn(),
                        template.getOrganizedAt(),
                        template.getSubHeader(),
                        template.getContent()
                );
                return request;
            }
            case "new joinees":{
                Template request = new NewJoineeTemplate(
                        template.getTemplateType(),
                        template.getCreatedBy(),
                        template.getJoiningDate(),
                        template.getTitle(),
                        template.getJoinees()
                );
                return request;
            }
            case "achievement":{
                Template request = new AchievementTemplate(
                        template.getTemplateType(),
                        template.getCreatedBy(),
                        template.getDate(),
                        template.getTitle(),
                        template.getAchievements()
                );
                return request;
            }
            case "job openings":{
                Template request = new JobOpeningsTemplate(
                        template.getTemplateType(),
                        template.getCreatedBy(),
                        template.getCompanyName(),
                        template.getJobPortalName(),
                        template.getWebsiteUrl(),
                        template.getDeadline(),
                        template.getVacancies()
                );
                return request;
            }
            default: return null;
        }
    }


}
