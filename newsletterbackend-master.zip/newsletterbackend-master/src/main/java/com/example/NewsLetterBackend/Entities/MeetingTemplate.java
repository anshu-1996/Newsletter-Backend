package com.example.NewsLetterBackend.Entities;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Getter
@Setter
@ToString
public class MeetingTemplate extends Template{
    String meetingHeldBy;
    @JsonFormat(pattern = "yyyy-MM-dd")
    Date meetingHeldOn;
    String organizedAt;
    String subHeader;
    String content;
    public MeetingTemplate(){}
    public MeetingTemplate(String templateType, String createdBy, String meetingHeldBy, Date meetingHeldOn, String organizedAt, String subHeader, String content) {
        super(templateType, createdBy);
        this.meetingHeldBy = meetingHeldBy;
        this.meetingHeldOn = meetingHeldOn;
        this.organizedAt = organizedAt;
        this.subHeader = subHeader;
        this.content = content;
    }
}
