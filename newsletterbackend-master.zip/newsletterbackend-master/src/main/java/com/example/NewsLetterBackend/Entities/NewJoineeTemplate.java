package com.example.NewsLetterBackend.Entities;

import com.example.NewsLetterBackend.Util.InfoPair;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;
@Getter
@Setter
@ToString
public class NewJoineeTemplate extends Template{
    @JsonFormat(pattern = "yyyy-MM-dd")
    Date joiningDate;
    String title;
    ArrayList<InfoPair> joinees;
    public NewJoineeTemplate(){}
    public NewJoineeTemplate(String templateType, String createdBy, Date joiningDate, String title, ArrayList<InfoPair> joinees) {
        super(templateType, createdBy);
        this.joiningDate = joiningDate;
        this.joinees = joinees;
        this.title = title;
    }

    public NewJoineeTemplate(long templateId, String templateType, String createdBy, Date joiningDate, String title, ArrayList<InfoPair> joinees) {
        super(templateId, templateType, createdBy);
        this.joiningDate = joiningDate;
        this.joinees = joinees;
        this.title = title;
    }
}
