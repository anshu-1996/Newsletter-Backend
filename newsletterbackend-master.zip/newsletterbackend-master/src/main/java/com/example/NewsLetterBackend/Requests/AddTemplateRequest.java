package com.example.NewsLetterBackend.Requests;


import com.example.NewsLetterBackend.Entities.User;
import com.example.NewsLetterBackend.Util.InfoPair;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.ArrayList;
import java.util.Date;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AddTemplateRequest {
    //Generic template attribute
    String templateType;
    String createdBy;
    // Fun event attribute
    String eventName;
    String eventDescription;
    String venue;
    @JsonFormat(pattern = "yyyy-MM-dd")
    Date eventOn;
    // Meeting updates attributes
    String meetingHeldBy;
    @JsonFormat(pattern = "yyyy-MM-dd")
    Date meetingHeldOn;
    String organizedAt;
    String subHeader;
    String content;
    // New Joinee Attributes
    Date joiningDate;
    String title;
    ArrayList<InfoPair> joinees;
    // Achievements attribute
    Date date;
    ArrayList<String> achievements;
    // JobOpeningsTemplate
    String companyName;
    String jobPortalName;
    String websiteUrl;
    Date deadline;
    ArrayList<String> vacancies;

//    public AddTemplateRequest(){
//
//    }

//    public AddTemplateRequest(String templateType, String createdBy, String eventName, String eventDescription, String venue, Date eventOn, String meetingHeldBy, Date meetingHeldOn, String organizedAt, String subHeader, String content, Date joiningDate, String title, ArrayList<InfoPair> joinees, Date date, ArrayList<String> achievements, String companyName, String jobPortalName, String websiteUrl, Date deadline, ArrayList<String> vacancies) {
//        this.templateType = templateType;
//        this.createdBy = createdBy;
//        this.eventName = eventName;
//        this.eventDescription = eventDescription;
//        this.venue = venue;
//        this.eventOn = eventOn;
//        this.meetingHeldBy = meetingHeldBy;
//        this.meetingHeldOn = meetingHeldOn;
//        this.organizedAt = organizedAt;
//        this.subHeader = subHeader;
//        this.content = content;
//        this.joiningDate = joiningDate;
//        this.title = title;
//        this.joinees = joinees;
//        this.date = date;
//        this.achievements = achievements;
//        this.companyName = companyName;
//        this.jobPortalName = jobPortalName;
//        this.websiteUrl = websiteUrl;
//        this.deadline = deadline;
//        this.vacancies = vacancies;
//    }

    public AddTemplateRequest(String templateType, String createdBy, String eventName, String eventDescription, String venue, Date eventOn, String meetingHeldBy, Date meetingHeldOn, String organizedAt, String subHeader, String content, Date joiningDate, String title, ArrayList<InfoPair> joinees, Date date, ArrayList<String> achievements) {
        this.templateType = templateType;
        this.createdBy = createdBy;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.venue = venue;
        this.eventOn = eventOn;
        this.meetingHeldBy = meetingHeldBy;
        this.meetingHeldOn = meetingHeldOn;
        this.organizedAt = organizedAt;
        this.subHeader = subHeader;
        this.content = content;
        this.joiningDate = joiningDate;
        this.title = title;
        this.joinees = joinees;
        this.date = date;
        this.achievements = achievements;
    }

//    public AddTemplateRequest(long templateId,String templateType, String createdBy, Date joiningDate, String title, ArrayList<InfoPair> joinees) {
//        this.templateId = templateId;
//        this.templateType = templateType;
//        this.createdBy = createdBy;
//        this.joiningDate = joiningDate;
//        this.title = title;
//        this.joinees = joinees;
//    }
//
//    public AddTemplateRequest(long templateId, String companyName, String jobPortalName, String websiteUrl, Date deadline, ArrayList<String> vacancies) {
//        this.templateId = templateId;
//        this.companyName = companyName;
//        this.jobPortalName = jobPortalName;
//        this.websiteUrl = websiteUrl;
//        this.deadline = deadline;
//        this.vacancies = vacancies;
//    }

}
