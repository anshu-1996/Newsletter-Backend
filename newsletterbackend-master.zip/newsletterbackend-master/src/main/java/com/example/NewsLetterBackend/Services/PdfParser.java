package com.example.NewsLetterBackend.Services;

import com.example.NewsLetterBackend.Entities.*;
import com.example.NewsLetterBackend.Repositories.TemplateRepository;
import com.example.NewsLetterBackend.Repositories.UserRepository;
import com.example.NewsLetterBackend.Util.InfoPair;
import com.example.NewsLetterBackend.Util.PdfManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


@Service
public class PdfParser {
    String[] templateData;
    String currentUser;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private TemplateRepository templateRepository;
    @Autowired
    private TemplateService templateService;
    @Autowired
    private SequenceGeneratedService sequenceGeneratedService;

    private final static Logger LOGGER =
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

    public PdfParser(){}

    public Template createTemplate(String fileName, String username) throws ParseException {
        PdfManager pdfManager = new PdfManager();
        pdfManager.setFilePath("/"+fileName);
        try {
            String text = pdfManager.toText();
            String[] temp = (text.split("\n"));
            this.templateData = temp;
        } catch (IOException ex) {
            Logger.getLogger(PdfParser.class.getName()).log(Level.SEVERE, null, ex);
        }
        //
        //
        this.currentUser = username;
        String templateType = (templateData[0].split(" ", 3))[2].strip();
        //LOGGER.log(Level.INFO, (templateType));
        switch(templateType){
            case "fun":{
                String createdBy = null;
                String description = null;
                String eventName = null;
                String venue = null;
                Date eventOn = null;
                for(String str: templateData){
                    try {
                        int temp = Integer.parseInt((((str.split(" ", 3))[0]).split("\\."))[0]);
                        String attribute = ((str.split(" ", 3))[1]).strip();
                        String value = (str.split(" ", 3))[2].strip();
                        switch(attribute){
                            case "Created-by":{
                                createdBy = value.strip();break;
                            }
                            case "Fun_event_on":{
                                eventOn = new SimpleDateFormat("yyyy-MM-dd").parse(value);break;
                            }
                            case "event_name":{
                                eventName = value.strip();break;
                            }
                            case "fun_description":{
                                description = value.strip();break;
                            }
                            case "venue":{
                                venue = value.strip();break;
                            }
                            default:continue;
                        }
                    }
                    catch (NumberFormatException e){
                        if(!str.isEmpty())
                            description += str;
                    }
                }
                Template template = new FunTemplate(templateType, username, eventName, description, venue, eventOn);
                //createTemplate(template);
                return template;
            }
            case "meeting":{LOGGER.log(Level.INFO, ("hello **2"));
                String createdBy = null;
                Date meetingHeldOn = null;
                String venue = null;
                String meetingHeader = null;
                String meetingContent = null;
                String meetingHeldBy = null;
                for(String str: templateData){
                    try{
                        int temp = Integer.parseInt((((str.split(" ", 3))[0]).split("\\."))[0]);
                        String attribute = ((str.split(" ", 3))[1]).strip();
                        String value = (str.split(" ", 3))[2].strip();
                        switch(attribute){
                            case "Created-by":{
                                createdBy = value;break;
                            }
                            case "Meeting_held_on":{
                                meetingHeldOn = new SimpleDateFormat("yyyy-MM-dd").parse(value);break;
                            }
                            case "Meeting_header":{
                                meetingHeader = value;break;
                            }
                            case "meeting_content":{
                                meetingContent = value;break;
                            }
                            case "meeting_held_by":{
                                meetingHeldBy = value;break;
                            }
                            case "venue":{
                                venue = value;break;
                            }
                            default:continue;
                        }
                    }
                    catch(NumberFormatException e){
                        if(!str.strip().isEmpty())
                            meetingContent += str;
                    }
                }

                Template template = new MeetingTemplate(templateType,username, meetingHeldBy,meetingHeldOn,venue,meetingHeader,meetingContent);
                //createTemplate(template);
                return template;
            }
            case "new joinees":{
                String createdBy = null;
                Date joiningDate = null;
                String joineesHeader = null;
                ArrayList<InfoPair> details = new ArrayList<>();
                for(int i=0;i<templateData.length;i++){
                    String str = templateData[i];
                    try{
                        int temp = Integer.parseInt((((str.split(" ", 3))[0]).split("\\."))[0]);
                        String attribute = ((str.split(" ", 3))[1]).strip();
                        String value = (str.split(" ", 3))[2].strip();
                        switch(attribute){
                            case "Created-by":{
                                createdBy = value;break;
                            }
                            case "Joining_date":{
                                joiningDate = new SimpleDateFormat("yyyy-MM-dd").parse(value);break;
                            }
                            case "Joinees_header":{
                                joineesHeader = value;break;
                            }
                            case "Joinees_details":{
//                                InfoPair info = new InfoPair(value.split(" ")[0], value.split(" ")[1]);
//                                details.add(info);
//                                break;
                                try{
                                    int temp2 = Integer.parseInt((((templateData[i+1].split(" ", 3))[0]).split("\\."))[0]);
                                    continue;
                                }
                                catch(NumberFormatException e){
                                    String value3 = (templateData[i].split(" ", 3))[2].strip();
                                    char checker;
                                    String text = "";
                                    String user = null;
                                    InfoPair infoPair = null;
                                    do {
                                        if(value3 == null){
                                            value3 = (templateData[i]).strip();
                                        }
                                        String character = (((value3.split(" ", 2))[0])).strip();
                                        char ch = character.charAt(0);
                                        if (ch == 10146) {
                                            if(user != null){
                                                infoPair = new InfoPair(user, text);
                                                details.add(infoPair);
                                            }
                                            user = ((value3.split(" ", 3))[1]);
                                            text = ((value3.split(" ", 3))[2]);
                                            text += '\n';
                                        } else {
                                            text += ' ';
                                            text += value3;
                                        }
                                        i++;
                                        String test = (((templateData[i].split(" ", 3))[0]).split("\\."))[0];
                                        try {
                                            checker = test.charAt(0);
                                        }
                                        catch(IndexOutOfBoundsException e1){
                                            break;
                                        }
                                        value3 = null;
                                    }while(!(checker>='0' && checker<='9'));
                                    i--;details.add(infoPair);
                                }
                            }
                            default:continue;
                        }
                    }
                    catch(NumberFormatException e){
//                        if(!str.strip().isEmpty())
//                            details.add(new InfoPair(str.split(" ")[0], str.split(" ")[1]));
                        LOGGER.log(Level.INFO, "stuck at wrong place");
                    }
                }
                Template template = new NewJoineeTemplate(templateType,username, joiningDate, joineesHeader, details);
                //LOGGER.log(Level.INFO, String.valueOf((addTemplateRequest.getTemplateId())));
                //createTemplate(template);
                return template;

            }
            case "achievement":{
                String createdBy = null;
                String achievementTitle = null;
                Date achievedOn = null;
                ArrayList<String> details = new ArrayList<>();
                for(int i=0;i<templateData.length;i++){
                    String str = templateData[i];
                    try{
                        int temp = Integer.parseInt((((str.split(" ", 3))[0]).split("\\."))[0]);
                        String attribute = ((str.split(" ", 3))[1]).strip();
                        String value = (str.split(" ", 3))[2].strip();
                        switch (attribute){
                            case "Created-by":{
                                createdBy = value;break;
                            }
                            case "Achieved_on": {
                                achievedOn = new SimpleDateFormat("yyyy-MM-dd").parse(value);break;
                            }
                            case "Achievement_title": {
                                achievementTitle = value;break;
                            }
                            case "achievements_details":{
                                try{
                                    int temp2 = Integer.parseInt((((templateData[i+1].split(" ", 3))[0]).split("\\."))[0]);
                                    continue;
                                }
                                catch(NumberFormatException e){
                                    String value3 = (templateData[i].split(" ", 3))[2].strip();
                                    char checker;
                                    String newAchievement = null;
                                    do {
                                        if(value3 == null){
                                            value3 = (templateData[i]).strip();
                                        }
                                        String character = (((value3.split(" ", 2))[0])).strip();
                                        char ch = character.charAt(0);
                                        if (ch == 10146) {
                                            if(newAchievement != null)
                                                details.add(newAchievement);
                                            newAchievement = ((value3.split(" ", 2))[1]);
                                        } else {
                                            newAchievement += ' ';
                                            newAchievement += value3;
                                        }
                                        i++;
                                        String test = (((templateData[i].split(" ", 3))[0]).split("\\."))[0];
                                        try {
                                            checker = test.charAt(0);
                                        }
                                        catch(IndexOutOfBoundsException e1){
                                            break;
                                        }
                                        value3 = null;
                                    }while(!(checker>='0' && checker<='9'));
                                    i--;details.add(newAchievement);
                                }
                            }
                            default:continue;
                        }
                    }
                    catch(NumberFormatException e){
                        if(!str.strip().isEmpty())
                            details.add(str);
                    }
                }

                Template template = new AchievementTemplate(templateType, username,achievedOn,achievementTitle,details);
                //createTemplate(template);
                return template;
            }
            case "job openings":{
                String createdBy = null;
                Date openingDeadline = null;
                String companyName = null;
                String jobPortal = null;
                String websiteUrl = null;
                ArrayList<String> vacancies = new ArrayList<>();

                for(String str: templateData){
                    try{
                        int temp = Integer.parseInt((((str.split(" ", 3))[0]).split("\\."))[0]);
                        String attribute = ((str.split(" ", 3))[1]).strip();
                        String value = (str.split(" ", 3))[2].strip();
                        switch(attribute){
                            case "Created-by":{
                                createdBy = value;break;
                            }
                            case "opening_deadline":{
                                openingDeadline = new SimpleDateFormat("yyyy-MM-dd").parse(value);break;
                            }
                            case "company_name":{
                                companyName = value;break;
                            }
                            case "job_portal":{
                                jobPortal = value;break;
                            }
                            case "website_url":{
                                websiteUrl = value;break;
                            }
                            case "vacancies":{
                                vacancies.add(value);
                            }
                            default:continue;
                        }
                    }
                    catch(NumberFormatException e){
                        if(!str.strip().isEmpty())
                            vacancies.add(str);
                    }
                }

                Template template = new JobOpeningsTemplate(templateType, username, companyName, jobPortal, websiteUrl,openingDeadline,vacancies);
                //this.createTemplate(template);
                return template;
            }
            default:{return null;}
        }
    }

    public void createTemplate(Template template){
        template.setTemplateId(sequenceGeneratedService.getSequenceNumber(Template.SEQUENCE_NAME));
        template.setCreatedBy(this.currentUser);
        User user = userRepository.findByusername(template.getCreatedBy());
        if(user != null){
            if(user.getDocuments() == null)
                user.setDocuments(new ArrayList<>());
            user.getDocuments().add(template);
            userRepository.save(user);
        }
        templateRepository.save(template);
    }
}
