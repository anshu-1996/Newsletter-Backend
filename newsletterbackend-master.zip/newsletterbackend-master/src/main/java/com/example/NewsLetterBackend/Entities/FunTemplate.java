package com.example.NewsLetterBackend.Entities;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
@Getter
@Setter
@ToString
public class FunTemplate extends Template{
    String eventName;
    String eventDescription;
    String venue;
    @JsonFormat(pattern = "yyyy-MM-dd")
    Date eventOn;
    public FunTemplate(){}
    public FunTemplate(String templateType, String createdBy, String eventName, String eventDescription, String venue, Date eventOn) {
        super(templateType, createdBy);
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.venue = venue;
        this.eventOn = eventOn;
    }
}
