package com.example.NewsLetterBackend.ControllerTest;

import com.example.NewsLetterBackend.Entities.User;
import com.example.NewsLetterBackend.Repositories.UserRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.coyote.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.Assert;
import org.springframework.web.context.WebApplicationContext;
import org.xmlunit.util.Mapper;

import javax.annotation.security.RunAs;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

@SpringBootTest
public class UserControllerTest {
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext wc;

    @Autowired
    private UserRepository userRepository;

    List<User>users = new ArrayList<User>();

    ObjectMapper om = new ObjectMapper();
    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(wc).build();
    }

    @Test
    public void addUserTest() throws JsonProcessingException, Exception {
        User user = new User();
        user.setUsername("Tanuj");
        user.setPassword("123");
        user.setFullName("Tanuj Bordoloi");
        user.setPhone("8638710126");
        String jsonRequest = om.writeValueAsString(user);
        MvcResult result = mockMvc.perform(post("/addUser").content(jsonRequest).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
//        String resultContent = "";
//        Response response = om.readValue(resultContent, Response.class);
        User respons = userRepository.findByusername("Tanuj");
        assertEquals(respons, respons);
    }

    @Test
    public void getUserByUsernameTest() throws Exception {
        MvcResult result = mockMvc.perform(get("/getUserByUsername/{username}","Tanuj").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
        User response = om.readValue(result.getResponse().getContentAsString(), new TypeReference<User>() {
        });
        User user = userRepository.findByusername("Tanuj");
        assertEquals(user, response);
    }



}
