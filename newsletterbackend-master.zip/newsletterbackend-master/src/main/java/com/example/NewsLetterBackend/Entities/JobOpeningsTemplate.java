package com.example.NewsLetterBackend.Entities;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;

@Getter
@Setter
@ToString
public class JobOpeningsTemplate extends Template{
    String companyName;
    String jobPortalName;
    String websiteUrl;
    Date deadline;
    ArrayList<String> vacancies;
    public JobOpeningsTemplate(){}
    public JobOpeningsTemplate(String templateType, String createdBy, String companyName, String jobPortalName, String websiteUrl, Date deadline, ArrayList<String> vacancies) {
        super(templateType, createdBy);
        this.companyName = companyName;
        this.jobPortalName = jobPortalName;
        this.websiteUrl = websiteUrl;
        this.deadline = deadline;
        this.vacancies = vacancies;
    }
}
