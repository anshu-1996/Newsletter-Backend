package com.example.NewsLetterBackend.Controllers;

import com.example.NewsLetterBackend.Entities.Template;
import com.example.NewsLetterBackend.Services.MyUserDetailsService;
import com.example.NewsLetterBackend.Entities.User;
import com.example.NewsLetterBackend.Services.SequenceGeneratedService;
import com.example.NewsLetterBackend.Services.UserService;
import com.example.NewsLetterBackend.models.AuthenticationRequest;
import com.example.NewsLetterBackend.models.AuthenticationResponse;
import com.example.NewsLetterBackend.Util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
//@RequestMapping("/auth")
@CrossOrigin(origins = {"https://newsletterfrontend-amxbp6pvia-as.a.run.app/","http://localhost:4200"})
public class UserController {
    private final static Logger LOGGER =
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    @Autowired
    private UserService userService;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private MyUserDetailsService userDetailsService;
    @Autowired
    private JwtUtil jwtTokenUtil;

    @Autowired
    private SequenceGeneratedService sequenceGeneratedService;

    @PostMapping("/authenticate")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest) throws Exception {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword())
            );
        } catch (BadCredentialsException e) {
            throw new Exception("Incorrect Username or Password", e);
        }
        final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
        final String jwt = jwtTokenUtil.generateToken(userDetails);
        return ResponseEntity.ok(new AuthenticationResponse(jwt));
    }
    @PostMapping("/addUser")
    public ResponseEntity<?> saveUser(@RequestBody User user) {

        LOGGER.log(Level.INFO, user.getUsername());
        LOGGER.log(Level.INFO, user.getFullName());
        LOGGER.log(Level.INFO, user.getPassword());
        User userdata = userService.getUserByUsername(user.getUsername());
        if(userdata != null) {
            return null;
        }
        user.setId(sequenceGeneratedService.getSequenceNumber(User.SEQUENCE_NAME));
        userService.saveUser(user);
        final UserDetails userDetails = new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), new ArrayList<>());

        final String jwt = jwtTokenUtil.generateToken(userDetails);
        LOGGER.log(Level.INFO, (jwt));
        return ResponseEntity.ok(new AuthenticationResponse(jwt));
    }
    @GetMapping("/getAllUser")
    public List<User> getAllUser() {
        return userService.getAllUser();
    }
    @GetMapping("/getUserByUsername/{username}")
    public User getUserByUsername(@PathVariable String username) {
        return userService.getUserByUsername(username);
    }
    //    @DeleteMapping
//    public void deleteUserById(@PathVariable int id) {
//        userService.deleteUser(id);
//    }
    @PutMapping("updateUser/{username}")
    public User updateUserById(@RequestBody User user, @PathVariable String username)
    {
        return userService.updateUser(user, username);
    }
    @GetMapping("getDocuments/{username}")
    public List<Template> getDocumentsByUsername(@PathVariable String username){
        return userService.getDocumentsByUsername(username);
    }
}
