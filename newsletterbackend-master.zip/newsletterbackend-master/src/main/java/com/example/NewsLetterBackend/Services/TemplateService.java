package com.example.NewsLetterBackend.Services;

import com.example.NewsLetterBackend.Converters.TemplateConverter;
import com.example.NewsLetterBackend.Entities.*;
import com.example.NewsLetterBackend.Repositories.TemplateRepository;
import com.example.NewsLetterBackend.Repositories.UserRepository;
import com.example.NewsLetterBackend.Requests.AddTemplateRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class TemplateService {
    private final TemplateRepository templateRepository;
    private final UserRepository userRepository;
    @Autowired
    private SequenceGeneratedService sequenceGeneratedService;

    private final static Logger LOGGER =
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

    @Autowired
    public TemplateService(TemplateRepository templateRepository, UserRepository userRepository) {
        this.templateRepository = templateRepository;
        this.userRepository = userRepository;
    }

    public Template saveTemplate(AddTemplateRequest addTemplateRequest, String username){
        //LOGGER.log(Level.INFO, ("hello world!"));
        Template template = TemplateConverter.toEntity(addTemplateRequest);
        template.setCreatedBy(username);
        template.setTemplateId(sequenceGeneratedService.getSequenceNumber(Template.SEQUENCE_NAME));
        //LOGGER.log(Level.INFO, String.valueOf((template.getTemplateId())));
        User user = userRepository.findByusername(username);
        if(user != null){
            if(user.getDocuments()==null){
                user.setDocuments(new ArrayList<>());
            }
            template.setCreatedBy(username);
            List<Template> temp = user.getDocuments();
            temp.add(template);
            user.setDocuments(temp);
            userRepository.save(user);
        }
        return templateRepository.save(template);
    }
    public List<Template> getAllTemplate(){
        return templateRepository.findAll();
    }
    public Optional<Template> getTemplateById(Long id)
    {
        return templateRepository.findById(id);
    }

    public String deleteTemplateById(Long id, String username) throws NoSuchElementException{
        Optional<Template> template = templateRepository.findById(id);
        Template template1 = null;
        try{
            template1 = template.get();
        }
        catch(NoSuchElementException e){
            throw new NoSuchElementException("Template not found with given id");
        }
        User user = userRepository.findByusername(username);
        if(user != null){
            if(user.getDocuments()!=null){
                List<Template> temp = user.getDocuments();
                temp.remove(template1);
                user.setDocuments(temp);
                userRepository.save(user);
            }
        }
        templateRepository.deleteById(id);
        return "Template deleted successfully";
    }

    public Template updateTemplate(AddTemplateRequest addTemplateRequest, long id) {
        Template template = TemplateConverter.toEntity(addTemplateRequest);
        template.setTemplateId(id);
        User user = userRepository.findByusername(template.getCreatedBy());
        if(user != null){
            if(user.getDocuments() == null)
                user.setDocuments(new ArrayList<>());
            Optional<Template> temp = templateRepository.findById(id);
            List<Template> document = user.getDocuments();document.remove(temp.get());
            document.add(template);
            user.setDocuments(document);
            userRepository.save(user);
        }
        return templateRepository.save(template);
    }

}
