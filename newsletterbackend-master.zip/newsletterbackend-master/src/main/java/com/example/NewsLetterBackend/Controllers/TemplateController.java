package com.example.NewsLetterBackend.Controllers;

import com.example.NewsLetterBackend.Entities.*;
import com.example.NewsLetterBackend.Requests.AddTemplateRequest;
import com.example.NewsLetterBackend.Services.SequenceGeneratedService;
import com.example.NewsLetterBackend.Services.TemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = {"https://newsletterfrontend-amxbp6pvia-as.a.run.app/","http://localhost:4200"})
public class TemplateController {
    @Autowired
    private TemplateService templateService;
    @Autowired
    private SequenceGeneratedService sequenceGeneratedService;

    @GetMapping("/")
    public String print(){
        return "NewsLetter";
    }

    @PostMapping("/{username}/Template/add")
    public Template saveTemplate(@RequestBody AddTemplateRequest template,@PathVariable String username){
        return templateService.saveTemplate(template, username);
    }
    @GetMapping("/Template/get/all")
    public List<Template> getAllTemplate(){

        return templateService.getAllTemplate();
    }
    @GetMapping("/Template/get/{id}")
    public Optional<Template> getTemplateById(@PathVariable Long id){
        return templateService.getTemplateById(id);
    }
    @DeleteMapping("/{username}/Template/delete/{id}")
    public String deleteTemplateById(@PathVariable String username,@PathVariable Long id){
        return templateService.deleteTemplateById(id, username);
    }
    @PutMapping("/Template/update/{id}")
    public Template updateTemplate(@RequestBody AddTemplateRequest template, @PathVariable long id)
    {
        return templateService.updateTemplate(template, id);
    }
}
