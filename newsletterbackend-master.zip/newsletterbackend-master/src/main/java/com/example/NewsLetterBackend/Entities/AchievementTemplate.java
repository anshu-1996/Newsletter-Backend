package com.example.NewsLetterBackend.Entities;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;

@Getter
@Setter
@ToString
public class AchievementTemplate extends Template {
    @JsonFormat(pattern = "yyyy-MM-dd")
    Date date;
    String title;
    ArrayList<String> achievements;
    public AchievementTemplate(String templateType, String createdBy, Date date, String title, ArrayList<String> achievements) {
        super(templateType, createdBy);
        this.date = date;
        this.title = title;
        this.achievements = achievements;
    }
}
