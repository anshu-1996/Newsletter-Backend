package com.example.NewsLetterBackend.Entities;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
@Data


@Document(collection = "User")
public class User {
    @Transient
    public static final String SEQUENCE_NAME = "user_sequence";

    @Id
    Integer id;
    String username;
    String password;
    String fullName;
    String phone;
    //    String description;
    List<Template> documents;

    public User() {
    }

    public User(String username, String password, String fullName, String phone, List<Template> documents) {

        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.phone = phone;
//        this.description = description;
        this.documents = new ArrayList<>();
    }


}
