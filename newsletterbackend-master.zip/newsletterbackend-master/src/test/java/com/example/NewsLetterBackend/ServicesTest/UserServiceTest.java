package com.example.NewsLetterBackend.ServicesTest;

import com.example.NewsLetterBackend.Entities.User;
import com.example.NewsLetterBackend.Repositories.UserRepository;
import com.example.NewsLetterBackend.Services.UserService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;


import java.util.ArrayList;
import java.util.List;
import java.util.*;
import java.text.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;


import static org.mockito.Mockito.when;


public class UserServiceTest {
    @InjectMocks
    UserService userService;
    @Mock
    UserRepository userRepository;
    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    public void getUserByusernameTest() {
        User list = new User("test", "123", "Sumit Saha", "8638710126", new ArrayList<>());

        when(userRepository.findByusername("test")).thenReturn((User) list);
        User user = userService.getUserByUsername("test");

        assertEquals("test", user.getUsername());
        assertEquals("123", user.getPassword());
        assertEquals("Sumit Saha", user.getFullName());
        assertEquals("8638710126", user.getPhone());
    }

    @Test
    public void getUserByusernameNotTest() {
        User list = new User("test", "123", "Sumit Saha", "8638710126", new ArrayList<>());

        when(userRepository.findByusername("test")).thenReturn((User) list);
        User user = userService.getUserByUsername("test");

        assertNotEquals("testModified", user.getUsername());
        assertNotEquals("456", user.getPassword());
        assertEquals("Sumit Saha", user.getFullName());
        assertEquals("8638710126", user.getPhone());
    }

    @Test
    public void addUserTest()
    {
        User userInput = new User("test", "123", "Sumit Saha", "8638710126", new ArrayList<>());
        User userExpected = new User("test", "123", "Sumit Saha", "8638710126", new ArrayList<>());

//        when(userService.saveUser(userInput)).thenReturn(userExpected);
        when(userRepository.save(userInput)).thenReturn(userExpected);

        User testResult =  userService.saveUser(userInput);
        assertEquals(testResult, userExpected);
    }



    @Test
    public void updateUserNotTest()
    {
        User userInput = new User("testModified", "123", "Sumit Saha", "8638710126", new ArrayList<>());
        User userExpected = new User("test", "123", "Sumit Saha", "8638710126", new ArrayList<>());
        User testResult =  userService.updateUser(userInput, "test");
        assertNotEquals(testResult, userExpected);
    }

}
