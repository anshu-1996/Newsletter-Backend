package com.example.NewsLetterBackend.Controllers;


import com.example.NewsLetterBackend.Entities.Template;
import com.example.NewsLetterBackend.Services.PdfParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.text.ParseException;

@RestController
@CrossOrigin(origins = {"https://newsletterfrontend-amxbp6pvia-as.a.run.app/","http://localhost:4200"})
public class FileUploadController {
    private final static Logger LOGGER =
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

    @Autowired
    PdfParser pdfParser;
    private String target = "/";

    @PostMapping("/{username}/uploadFile")
    public Template fileUpload(@RequestParam("File") MultipartFile file, @PathVariable String username) throws IOException, ParseException {
        File myFile = new File(target,file.getOriginalFilename());
        LOGGER.log(Level.INFO, file.getOriginalFilename());
        myFile.createNewFile();
        String fileName = file.getOriginalFilename();
        FileOutputStream fos = new FileOutputStream(myFile);
        fos.write(file.getBytes());
        fos.close();

        Template template = pdfParser.createTemplate(fileName, username);
        //return new ResponseEntity<Object>("The File Uploaded Successfully", HttpStatus.OK);
        return template;
    }

}
