package com.example.NewsLetterBackend.Entities;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.time.LocalDate;

@Getter
@Setter
@ToString
@Data
@Document(collection = "Template")
public class Template {
    @Transient
    public static final String SEQUENCE_NAME = "template_sequence";

    @Id
    long templateId;
    String templateType;

    @JsonFormat(pattern="yyyy-MM-dd")
    LocalDate createdOn;
    @JsonFormat(pattern="yyyy-MM-dd")
    LocalDate lastUpdatedOn;
    String createdBy;
    public Template(){}
    public Template(String templateType, String createdBy) {
        this.templateType = templateType;
        this.createdOn = LocalDate.now();
        this.lastUpdatedOn = LocalDate.now();
        this.createdBy = createdBy;
    }
    public Template(long templateId, String templateType, String createdBy) {
        this.templateId = templateId;
        this.templateType = templateType;
        this.createdOn = LocalDate.now();
        this.lastUpdatedOn = LocalDate.now();
        this.createdBy = createdBy;
    }
}
